package hyperate.hyperate4health;

import CLI.Model.FirstMonitor;
import CLI.Model.HRMonitor;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Optional;
import java.util.Properties;
import java.util.ResourceBundle;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;
import javafx.application.Platform;
import javafx.beans.binding.Bindings;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;


public class MainScreenController implements Initializable {

  private final int WINDOW_SIZE = 10;
  @FXML
  private Label ageLabel;
  @FXML
  private Label dobLabel;
  @FXML
  private Label nameLabel;
  @FXML
  private Label heartRateLabel;
  @FXML
  private CategoryAxis xAxis = new CategoryAxis();
  @FXML
  private NumberAxis yAxis = new NumberAxis();
  @FXML
  private LineChart<String, Integer> lineChart;
  private HRMonitor hrMonitor;
  private XYChart.Series<String, Integer> series;
  private String hyperateId;
  private int timeout;
  private String filepath;
  private TimerTask task;
  private Connection connection;
  private String databaseUser;
  private String databasePassword;
  private String databaseUrl;
  private boolean isRunning = false;
  private String name;
  private int age;
  private String dob;
  private boolean signin;

  private void setMonitor(String hyperateId, int timeout, String filepath) {
    this.hrMonitor = new FirstMonitor(hyperateId, timeout, filepath);

  }

  public void createMonitor(String hyperateId, int timeout, String filepath) {
    this.hyperateId = hyperateId;
    this.timeout = timeout;
    this.filepath = filepath;

    nameLabel.textProperty().bind(Bindings.concat("Name: ", name));
    ageLabel.textProperty().bind(Bindings.concat("Age: ", age));
    //put dob like yy/mm/dd
    dobLabel.textProperty().bind(Bindings.concat("DOB: ", dob));

    if (!isRunning) {
      return;
    }
    setMonitor(hyperateId, timeout, filepath);
  }

  @Override
  public void initialize(URL url, ResourceBundle resourceBundle) {

    //defining the axes
    lineChart.getParent();
    xAxis.setLabel("Time/s");
    xAxis.setAnimated(false); // axis animations are removed
    yAxis.setLabel("Value");
    yAxis.setAnimated(false); // axis animations are removed
    lineChart.setTitle("Heart Rate Monitor");
    lineChart.setAnimated(false); // disable animations
    //defining a series to display data
    series = new XYChart.Series<>();
    series.setName("Data Series");
    lineChart.getData().add(series);

    this.heartRateLabel.textProperty().bind(Bindings.concat("Heart Rate: ", "0"));
  }

  public void sendInfo(String hyperateId, String name, int age, String dob, String databaseUser,
                       String databasePassword, String databaseUrl, boolean signin) {
    this.hyperateId = hyperateId;
    this.name = name;
    this.age = age;
    this.dob = dob;
    this.databaseUser = databaseUser;
    this.databasePassword = databasePassword;
    this.databaseUrl = databaseUrl;
    this.signin = signin;

  }

  @FXML
  private void startButtonPressed() {

    //Create the monitor
    if (isRunning) {
      return;
    }
    isRunning = true;
    createMonitor(hyperateId, timeout, filepath);
    hrMonitor.start();
    beginTimer();
  }

  private void beginTimer() {
    task = new TimerTask() {
      @Override
      public void run() {

        Platform.runLater(() -> {
          SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
          String time = sdf.format(new Date());
          int hr;
          try {
            hr = hrMonitor.getHeartRate();
            series.getData().add(new XYChart.Data<>(time, hr));
            Set<Node> nodes = lineChart.lookupAll(".series" + 0);
            for (Node n : nodes) {
              n.setStyle("-fx-background-color: #000000, white;\n"
                      + "    -fx-background-insets: 0, 2;\n"
                      + "    -fx-background-radius: 5px;\n"
                      + "    -fx-padding: 5px;");
            }
            series.getNode().lookup(".chart-series-line").setStyle("-fx-stroke: black;");
            heartRateLabel.textProperty().bind(Bindings.concat("Heart Rate: ", hr));
            //Add to database
            if (signin) {
              try {
                connection = DriverManager.getConnection(databaseUrl, databaseUser, databasePassword);
                PreparedStatement preparedStatement =
                        connection.prepareStatement("Call insert_heart(?,?,?)");
                preparedStatement.setString(1, hyperateId);
                preparedStatement.setInt(2, hr);
                preparedStatement.setString(3,
                        new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
                preparedStatement.executeUpdate();

              } catch (SQLException e) {
                e.printStackTrace();
                new Alert(Alert.AlertType.ERROR, "Could not connect to database").showAndWait();
              }
            }
          } catch (NullPointerException e) {
            //Do nothing
          }
          if (series.getData().size() > WINDOW_SIZE) series.getData().remove(0);
        });
      }
    };
    Timer timer = new Timer();
    timer.schedule(task, 0, 3000);

  }

  @FXML
  private void quitButtonPressed() {

    if (hrMonitor == null) {
      return;
    }

    this.isRunning = false;
    this.hrMonitor.stopApplication();
    //Stop the graph
    task.cancel();
    series.getData().clear();
    heartRateLabel.textProperty().bind(Bindings.concat("Heart Rate: ", "0"));

  }

  @FXML
  private void save() {
    signIn();
  }

  private void saveData() {
    PreparedStatement preparedStatement;
    try {
      preparedStatement = connection.prepareStatement("Call insert_heart(?,?,?)");
      preparedStatement.setString(1, this.hyperateId);
      if (this.hrMonitor == null) {
        preparedStatement.setInt(2, 0);
      } else {
        preparedStatement.setInt(2, this.hrMonitor.getHeartRate());
      }
      preparedStatement.setString(
              3, new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
      preparedStatement.executeUpdate();
      new Alert(Alert.AlertType.INFORMATION, "Data saved successfully").showAndWait();
    } catch (SQLException e) {
      e.printStackTrace();
      new Alert(Alert.AlertType.ERROR, "Data could not be saved").showAndWait();
    }
  }

  private void signIn() {
    loginDialog();

  }

  public void loginDialog() {
    //Ask if the user wants to log in to the database
    Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
    alert.setTitle("Database Login");
    alert.setHeaderText("Database Login");
    alert.setContentText("Would you like to log in to the database?");
    Optional<ButtonType> result = alert.showAndWait();

    if (result.isPresent())
      if (result.get().equals(ButtonType.OK)) {
        GridPane gridPane = new GridPane();
        gridPane.setHgap(10);
        gridPane.setVgap(10);
        gridPane.setPadding(new Insets(20, 150, 10, 10));

        TextField databaseUser = new TextField();
        databaseUser.setPromptText("Database Username");
        gridPane.add(databaseUser, 0, 0);

        PasswordField databasePassword = new PasswordField();
        databasePassword.setPromptText("Database Password");
        gridPane.add(databasePassword, 0, 1);

        alert = new Alert(Alert.AlertType.NONE);
        alert.setTitle("Database Login");
        alert.setHeaderText("Database Login");
        alert.getDialogPane().setContent(gridPane);
        alert.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
        result = alert.showAndWait();
        this.databaseUser = databaseUser.getText();
        this.databasePassword = databasePassword.getText();
        if (result.isPresent())
          if (result.get().equals(ButtonType.OK)) {
            this.verifyDatabaseLogin();
          } else {
            this.nameLabel.getParent().setDisable(false);
          }
      } else {
        this.nameLabel.getParent().setDisable(false);
      }
  }

  private void verifyDatabaseLogin() {
    //Verify the login details
    //If correct, save the data to the database
    //If incorrect, display an error message
    try {
      this.connection = this.getConnection();
      this.saveData();
    } catch (SQLException e) {
      new Alert(Alert.AlertType.ERROR, "Incorrect login details").showAndWait();
      e.printStackTrace();
    }
  }

  /**
   * Get a new database connection
   *
   * @return The Connection Object
   * @throws SQLException if getConnection fails.
   */
  public Connection getConnection() throws SQLException {
    Properties connectionProps = new Properties();
    connectionProps.put("user", this.databaseUser);
    connectionProps.put("password", this.databasePassword);
    connection = DriverManager.getConnection(databaseUrl, connectionProps);

    return connection;
  }

  //handle closing the app
    @FXML
    private void handleClose() {
        if (hrMonitor != null) {
            hrMonitor.stopApplication();
        }
        Platform.exit();
    }
}
